import axios from 'axios';
import { useEffect, useState } from 'react';
import ElementsArticle from './ElementsArticle';

function ListArticles() {
  const [articles, setArticles] = useState([]);

  useEffect(() => {
    axios.get("http://localhost:3002/produits")
      .then((response) => setArticles(response.data))
      .catch((error) => console.error(error));
  }, []);

  const deleteProd = async (id) => {
    if (!window.confirm("Are you sure you want to delete")) {
      return;
    }

    try {
      await axios.delete(`http://localhost:3002/produits/${id}`);
      console.log('Successfully deleted!');
      setArticles((prevArticles) => prevArticles.filter((article) => article.id !== id));
    } catch (error) {
      console.error(error);
    }
  };

  return (
    <>
      <center><h2>Liste des articles</h2></center>
      <ElementsArticle articles={articles} deleteProd={deleteProd} />
    </>
  );
}

export default ListArticles;
