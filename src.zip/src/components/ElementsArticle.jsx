import { Link } from "react-router-dom";

function ElementsArticle({ articles, deleteProd }) {
  return (
    <div className="container-fluid p-0">
      <div className="row no-gutters">
        {articles.map((article) => {
          return (
            <div key={article.id} className="col-lg-4 col-md-6 col-sm-12 mb-4">
              <div className="card h-100">
                <img
                  src={article.imageartpetitf || "/fallback-image.jpg"}
                  className="card-img-top img-fluid"
                  alt={article.designation || "Article Image"}
                />
                <div className="card-body">
                  <h5 className="card-title">{article.designation}</h5>
                  <p className="card-text">{article.marque}</p>
                </div>
                <ul className="list-group list-group-flush">
                  <li className="list-group-item">{article.prixVente} TND</li>
                </ul>
                <div className="card-body">
                 <Link exact to={`/editArticle/${article.id}`} className="btn btn-primary">Modifier</Link>
                 <button onClick={() => deleteProd(article.id)} className="btn btn-danger">Supprimer</button>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

export default ElementsArticle;
