const ElementsArticleCard = ({ articles, addToCart }) => {
    const handleAddToCart = (product) => {
      if (addToCart) {
        addToCart(product);
      } else {
        console.log(`Product added to cart: ${product.designation}`);
      }
    };
  
    return (
      <>
        <div className="row">
          {articles && articles.map((product) => (
            <article className="col-sm-3" key={product.id}>
              <div className="card">
                <img
                  src={product.imageartpetitf}
                  className="card-img-top p-5"
                  alt={product.designation}
                />
              </div>
              <div className="text-center">
                <div>{product.designation.substr(0, 20)} ... </div>
                <div>Prix : {product.prixVente} TND </div>
              </div>
              <div className="text-center">
                <button
                  disabled={product.qtestock <= 1}
                  className="btn btn-warning"
                  onClick={() => handleAddToCart(product)}
                >
                  Add to Cart
                </button>
              </div>
            </article>
          ))}
        </div>
      </>
    );
  };
  
  export default ElementsArticleCard;
  