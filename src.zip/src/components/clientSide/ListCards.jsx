import axios from 'axios';
import { useEffect, useState } from 'react';
import ElementArticleCard from './ElementsArticleCard';

function ListArticlesCard() {
  const [articles, setArticles] = useState([]);
  const [cart, setCart] = useState([]);

  useEffect(() => {
    axios.get('http://localhost:3002/produits')
      .then((res) => {
        setArticles(res.data);
      })
      .catch((error) => {
        console.error(error);
      });
  }, []);

  const addToCart = (product) => {
    setCart((prevCart) => [...prevCart, product]);
    console.log(`${product.designation} added to cart!`);
  };

  return (
    <div className="container">
      <ElementArticleCard articles={articles} addToCart={addToCart} />
    </div>
  );
}

export default ListArticlesCard;
